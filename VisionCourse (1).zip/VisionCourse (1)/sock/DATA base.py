from flask import Flask, request, session, redirect, url_for, render_template

app = Flask(__name__)
app.secret_key = 'secret_key' 

users = {'admin': 'password'}  

@app.route('/')
def home():
    if 'username' in session:
        return f'Привет, {session["username"]}! <a href="/logout">Выйти</a>'
    return 'Вы не авторизованы. <a href="/login">Войти</a>'

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username in users and users[username] == password:
            session['username'] = username
            return redirect(url_for('home'))
        return 'Неправильный логин или пароль'
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)



